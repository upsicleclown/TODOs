# CS 398: Application Development

## Winter 2022 Final Report

**Noterific!**: A note-taking application for Blackberry Q-series, HP iPAQ and Palm Pilot.

![icon](uploads/40ed7abe79efce1164a999c8b085ff27/icon.jpg)

Team: Jeff Avery, Caroline Kierstead, Yuan (Constant) Chen, Xiaoyan Xu, Licheng Zhang (Team 100)

We meet MWF through the week. Meeting minutes are tracked [here](Meeting Minutes).


## Project Details
* [1. Introduction](Introduction)
* [2. Requirements](Requirements)
* [3. Analysis & Design](Analysis-Design)
* [4. Implementation](Implementation)
* [5. Testing](Testing)

## Usage Instructions
Here are some basic instructions for using Noterific.

* File-New to create a new note (alt. use the New Note button on the toolbar).
* File-Delete to remove the selected note. You will be prompted to confirm deletion.

## Installation Instructions
To install **Noterific**, use one of the installers below. You may need to provide a password to authenticate the installation. 

The [Sprint 3 Release](Sprint 3 Release) represents the final product release.

## Releases
* [Sprint 1 Release](Sprint 1 Release)
* [Sprint 2 Release](Sprint 2 Release)
* [Sprint 3 Release](Sprint 3 Release)