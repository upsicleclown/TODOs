_Describe the high-level architecture and show a diagram. Justify your choice of architecture based on the requirements._
* _Was this the same diagram that you started with? Did it evolve over time?_

_Describe at least one design pattern that you decided to implement. Describe why you made that 
choice._
* _Was this pattern useful? If not, why do you think it didn’t work?_