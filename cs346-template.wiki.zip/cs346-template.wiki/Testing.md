_What was your testing strategy?_

_Identify the different tests that you were able to perform._

_What testing framework did you use? Did it support your strategy adequately?_