# Fri Jan 14, 2022 @ 9:30 AM.

Present: Jeff Avery, Caroline Kierstead

Absent: Mickey Mouse

## Goals
Create your project and project plan in GitLab.
https://student.cs.uwaterloo.ca/~cs398/1-logistics/1-weekly-schedule/details/week02/

## Team Updates

*Format: What you did; what you're doing next; blocking issues.*

* Jeff. Created an icon; figuring out schedule; no blocking issues.
* Caroline. Setup GitLab project; figuring out permission issue that prevents Mickey from logging in; no blocking issues.