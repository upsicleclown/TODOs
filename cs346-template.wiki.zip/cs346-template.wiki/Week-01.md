# Fri Jan 7, 2022 @ 9:30 AM.

Present: Jeff Avery, Caroline Kierstead

Absent: Mickey Mouse

## Goals
Project setup described on the course website.
https://student.cs.uwaterloo.ca/~cs398/1-logistics/1-weekly-schedule/details/week01/

## Team Updates

*Format: What you did; what you're doing next; blocking issues.*

* Jeff. Completed project page setup; working on setting up templates for planning section; no blocking issues.
* Caroline. Setup Piazza; will email students once list is available; no blocking issues.