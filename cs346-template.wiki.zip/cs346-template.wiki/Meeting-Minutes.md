We meet every Friday from 9:30 AM - 10:00 AM. 

Here is a link to our online meeting space:
[https://zoom.us/...](https://zoom.us)

* [Week 01: Jan 7, 2022](Week 01)
* [Week 02: Jan 14, 2022](Week 02)

etc.