_What software development practices did you use, and why?_

_Are there practices that you found particularly effective? How did they help you meet your goals?_

_Are there practices that didn’t work well for your team? If so, what do you think went wrong? Why are they not suitable for your particular project?_