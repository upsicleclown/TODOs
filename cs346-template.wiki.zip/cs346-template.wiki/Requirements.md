## Baseline Definition
(1-paragraph, or 6-8 bullets) _Describe the requirements that you were provided up-front and which are required._

## Functional Requirements
(2 paragraphs, or 6-8 bullets) _List the functional requirements that your team identified._

## Non-Functional Requirements
(1 paragraph) _Non-functional requirements that your team identified. Identify the requirements and how you verified that each one was met._