This is our first sprint, which ran from Feb 7-18, 2022.

This sprint included the following functionality:
* Basic user interface, with window resizing.
* The ability to create a new note.
* Class implementation for middle-tier notes.
* Persisting notes into a local database.

Installers
* Windows installer
* macOS package