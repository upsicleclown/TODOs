This is our third sprint, which ran from Mar 14 to 25, 2022.

This sprint included the following functionality:

* Rich-text editing.
* Code fences i.e. syntax highlighting source code.

Installers

* Windows installer
* macOS package