## Description
(1-2 paragraphs) _State that this is a group project for CS 398. Provide a very brief description of what you built._

## Process & SDLC
(1-2 paragraphs) _Describe how your project is structured (e.g. initial planning, followed by 3 two-week sprints, each sprint concluding with a demo)._

## Project Tracking
(1-2 paragraphs) _Specifically discuss how you are tracking all of the project components; when and how often you are meeting; what artifacts you are producing to track the project itself._