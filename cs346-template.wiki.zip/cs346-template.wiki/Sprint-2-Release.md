This is our second sprint, which ran from Feb 28 to Mar 11, 2022.

This sprint included the following functionality:

* Web service, hosting a remote database. Notes are saved both locally and remotely.
* Ability to create, edit, delete notes.
* Sort by date.

Installers

* Windows installer
* macOS package